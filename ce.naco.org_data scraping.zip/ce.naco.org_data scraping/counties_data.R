rm(list=ls())
setwd("Your directory")

library(rjson)
library(RCurl)
counties    <- fromJSON(file ="./counties.txt")
indicators  <- fromJSON(file ="./indicators.txt")

male_pct <- fromJSON(getURL("https://ce.naco.org/python/data?dbset=Demographics&dbind=DEM_AG_Male_Pct|DEM_AG_Male|DEM_LT_Total&dbyear=2018"))
pop      <- fromJSON(getURL("https://ce.naco.org/python/data?dbset=Demographics&dbind=DEM_LT_Total_Density|DEM_LT_Total|DEM_LT_Total_Growth&dbyear=2018"))
edu      <- fromJSON(getURL("https://ce.naco.org/python/data?dbset=Education&dbind=EDU_EA_Bachelors_Degree_More_Pct|EDU_EA_Bachelors_Degree_More_Pct_CV|EDU_EA_Bachelors_Degree_More|EDU_EA_Bachelors_Degree_More_CV&dbyear=2017"))
admins   <- fromJSON(getURL("https://ce.naco.org/python/data?dbset=County_Governance&dbind=CGov_Admin_Administrator_Cat&dbyear=2015")) 

# Variable directory
x = list();x[as.vector(unlist(lapply(indicators, 
    function(dataset)sapply(names(dataset)[sapply(dataset, 
    function(var)is.list(var)&&!is.null(var[["db"]]))],
    function(name)dataset[[name]][["db"]]))))]=as.vector(unlist(lapply(indicators,
    function(dataset)sapply(names(dataset)[sapply(dataset,
    function(var)is.list(var)&&!is.null(var[["db"]]))],function(name)name))))

df = data.frame( Name = unlist(x))
write.csv(df,"variable_directory.csv")

# Male percentage data
  n_counties      <- length(male_pct$data)
  FIPS            <- c(1:n_counties)
  county_name     <- c(1:n_counties)
  state           <- c(1:n_counties)
  DEM_AG_Male_Pct <- c(1:n_counties)
  DEM_AG_Male     <- c(1:n_counties)
  DEM_LT_Total    <- c(1:n_counties)


for (i in 1:n_counties){
  FIPS[i]            <- male_pct$data[[i]][[1]]
  county_name[i]     <- counties[[male_pct$data[[i]][[1]]]]$County
  state[i]           <- counties[[male_pct$data[[i]][[1]]]]$State
  DEM_AG_Male_Pct[i] <- male_pct$data[[i]][[2]]
  DEM_AG_Male[i]     <- male_pct$data[[i]][[3]]
  DEM_LT_Total[i]    <- male_pct$data[[i]][[4]]
}
  male_pct_data      <- data.frame(FIPS, DEM_AG_Male_Pct,DEM_AG_Male,DEM_LT_Total)
  county_directory   <- data.frame(FIPS,county_name, state)
  write.csv(male_pct_data, "male_pct.csv")
  write.csv(county_directory,"county_directory.csv")
  
# Population 
  n_counties           <- length(pop$data)
  FIPS                 <- c(1:n_counties)
  DEM_LT_Total_Density <- c(1:n_counties)
  DEM_LT_Total         <- c(1:n_counties)
  DEM_LT_Total_Growth  <- c(1:n_counties)
  
  for (i in 1:n_counties){
    FIPS[i]                 <- pop$data[[i]][[1]]
    DEM_LT_Total_Density[i] <- pop$data[[i]][[2]]
    DEM_LT_Total[i]         <- pop$data[[i]][[3]]
    DEM_LT_Total_Growth[i]  <- pop$data[[i]][[4]]
  }
  
  population      <- data.frame(FIPS,DEM_LT_Total_Density, DEM_LT_Total, DEM_LT_Total_Growth)
  write.csv(population,"population.csv")
  
# Education
  n_counties                          <- length(edu$data)
  FIPS                                <- c(1:n_counties)
  EDU_EA_Bachelors_Degree_More_Pct    <- c(1:n_counties)
  EDU_EA_Bachelors_Degree_More_Pct_CV <- c(1:n_counties)
  EDU_EA_Bachelors_Degree_More        <- c(1:n_counties)
  EDU_EA_Bachelors_Degree_More_CV     <- c(1:n_counties)
  
  for (i in 1:n_counties){
    FIPS[i]                                <- edu$data[[i]][[1]]
    EDU_EA_Bachelors_Degree_More_Pct[i]    <- edu$data[[i]][[2]]
    EDU_EA_Bachelors_Degree_More_Pct_CV[i] <- edu$data[[i]][[3]]
    EDU_EA_Bachelors_Degree_More[i]        <- edu$data[[i]][[4]]
    EDU_EA_Bachelors_Degree_More_CV[i]     <- edu$data[[i]][[5]]
  }
  
  education      <- data.frame(FIPS,EDU_EA_Bachelors_Degree_More_Pct,
                               EDU_EA_Bachelors_Degree_More_Pct_CV, 
                               EDU_EA_Bachelors_Degree_More, EDU_EA_Bachelors_Degree_More_CV)
  write.csv(education,"education.csv")
  
# Administrator
  n_counties                   <- length(admins$data)
  FIPS                         <- c(1:n_counties)
  CGov_Admin_Administrator_Cat <- c(1:n_counties)
 
  list_counties = c(1:12, 62:n_counties)
  
  for (i in list_counties){
    FIPS[i]                         <- admins$data[[i]][[1]]
    CGov_Admin_Administrator_Cat[i] <- admins$data[[i]][[2]]
  }
  
  administrators      <- data.frame(FIPS,CGov_Admin_Administrator_Cat)
  administrators      <-  administrators[-c(13:61),]
  write.csv(administrators,"administrator.csv",row.names = FALSE, quote=FALSE)
  
  
  
  
  
  